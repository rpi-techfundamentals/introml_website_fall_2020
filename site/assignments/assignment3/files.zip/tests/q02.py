test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> list2
          [7, 14, 21, 28, 35, 42, 49]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list_divisible(5, 19, 2)
          [6, 8, 10, 12, 14, 16, 18]
          """,
          'hidden': False,
          'locked': False
        },
               {
          'code': r"""
          >>> list_divisible(5, 56, 7)
          [7, 14, 21, 28, 35, 42, 49]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}

