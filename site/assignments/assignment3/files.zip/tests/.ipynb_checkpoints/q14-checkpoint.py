test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> round(AccGenderAge13,2)
          79.24
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> round(AccGenderAge18,2)
          76.09
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
