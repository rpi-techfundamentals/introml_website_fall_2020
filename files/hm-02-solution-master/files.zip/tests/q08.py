test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> elist2
          [5, 4, 3, 2, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> len(elist1)
          5
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
