test = {
  'name': 'Question',
  'points': 6,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> round(model1_test_ROC,1)==0.7
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
