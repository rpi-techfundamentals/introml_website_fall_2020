test = {
  'name': 'Question',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> round(model1_test_mse,0)==8310.0
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
