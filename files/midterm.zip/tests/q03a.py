test = {
  'name': 'Question',
  'points': 6,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> round(model1_train_accuracy,1)==0.6
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
