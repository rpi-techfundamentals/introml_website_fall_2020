test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> len(first_name)>0
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> len(last_name)>0
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> len(student_id)>0
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> len(student_email)>0
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
