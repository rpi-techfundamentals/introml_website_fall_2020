test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> int(row_0_count_participants)
          44
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> int(row_0_count_hispanic_latino)
          16
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
