test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> x
          150
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> y
          1950
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> round(z,5)
          0.08667
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
